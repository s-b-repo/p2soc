#!/usr/bin/env python3
import os, sys, time, signal
open(os.environ["INODE_RUNS"], "a").write("1\n")          # count (re)connect attempts
open(os.environ["INODE_MARKER"], "w").write(
    os.environ.get("H3C_SVPN_PASSWORD", "") + " | argv=" + " ".join(sys.argv[1:]))
print("tunnel up: ip=10.9.9.2 mask=255.255.255.0", flush=True)
fail_after = os.environ.get("INODE_FAIL_AFTER")
if fail_after:                                            # simulate iNode heartbeat death
    time.sleep(float(fail_after))
    print("heartbeat: no response, going offline", flush=True)
    sys.exit(1)
signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
while True: time.sleep(0.3)
